/******************************************************************************/
/* Important Spring 2018 CSCI 402 usage information:                          */
/*                                                                            */
/* This fils is part of CSCI 402 kernel programming assignments at USC.       */
/*         53616c7465645f5f2e8d450c0c5851acd538befe33744efca0f1c4f9fb5f       */
/*         3c8feabc561a99e53d4d21951738da923cd1c7bbd11b30a1afb11172f80b       */
/*         984b1acfbbf8fae6ea57e0583d2610a618379293cb1de8e1e9d07e6287e8       */
/*         de7e82f3d48866aa2009b599e92c852f7dbf7a6e573f1c7228ca34b9f368       */
/*         faaef0c0fcf294cb                                                   */
/* Please understand that you are NOT permitted to distribute or publically   */
/*         display a copy of this file (or ANY PART of it) for any reason.    */
/* If anyone (including your prospective employer) asks you to post the code, */
/*         you must inform them that you do NOT have permissions to do so.    */
/* You are also NOT permitted to remove or alter this comment block.          */
/* If this comment block is removed or altered in a submitted file, 20 points */
/*         will be deducted.                                                  */
/******************************************************************************/

/*
 *  FILE: open.c
 *  AUTH: mcc | jal
 *  DESC:
 *  DATE: Mon Apr  6 19:27:49 1998
 */

#include "globals.h"
#include "errno.h"
#include "fs/fcntl.h"
#include "util/string.h"
#include "util/printf.h"
#include "fs/vfs.h"
#include "fs/vnode.h"
#include "fs/file.h"
#include "fs/vfs_syscall.h"
#include "fs/open.h"
#include "fs/stat.h"
#include "util/debug.h"

/* find empty index in p->p_files[] */
int
get_empty_fd(proc_t *p)
{
        int fd;

        for (fd = 0; fd < NFILES; fd++) {
                if (!p->p_files[fd])
                        return fd;
        }

        dbg(DBG_ERROR | DBG_VFS, "ERROR: get_empty_fd: out of file descriptors "
            "for pid %d\n", curproc->p_pid);
        return -EMFILE;
}

/*
 * There a number of steps to opening a file:
 *      1. Get the next empty file descriptor.
 *      2. Call fget to get a fresh file_t.
 *      3. Save the file_t in curproc's file descriptor table.
 *      4. Set file_t->f_mode to OR of FMODE_(READ|WRITE|APPEND) based on
 *         oflags, which can be O_RDONLY, O_WRONLY or O_RDWR, possibly OR'd with
 *         O_APPEND or O_CREAT.
 *      5. Use open_namev() to get the vnode for the file_t.
 *      6. Fill in the fields of the file_t.
 *      7. Return new fd.
 *
 * If anything goes wrong at any point (specifically if the call to open_namev
 * fails), be sure to remove the fd from curproc, fput the file_t and return an
 * error.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EINVAL
 *        oflags is not valid.
 *      o EMFILE
 *        The process already has the maximum number of files open.
 *      o ENOMEM
 *        Insufficient kernel memory was available.
 *      o ENAMETOOLONG
 *        A component of filename was too long.
 *      o ENOENT
 *        O_CREAT is not set and the named file does not exist.  Or, a
 *        directory component in pathname does not exist.
 *      o EISDIR
 *        pathname refers to a directory and the access requested involved
 *        writing (that is, O_WRONLY or O_RDWR is set).
 *      o ENXIO
 *        pathname refers to a device special file and no corresponding device
 *        exists.
 */

int
do_open(const char *filename, int oflags)
{
        /*NOT_YET_IMPLEMENTED("VFS: do_open");*/
	/*handle error case: EINVAL. Make sure that only 1 of O_RDONLY, O_WRONLY, O_RDWR exits*/
        int mask = O_RDONLY | O_WRONLY | O_RDWR;
        mask = mask & oflags;
        if(!(mask == O_RDONLY || mask == O_WRONLY || mask == O_RDWR)){
            dbg(DBG_PRINT, "(GRADING2B)\n");
            return -EINVAL;
        }

	/*handle error case: EINVAL. Make sure that O_APPEND or O_CREATE is at the right position
        mask = O_APPEND | O_CREAT;
        mask = mask & oflags;
        if(mask == O_APPEND || mask == O_CREATE || mask == 0) {
            
        }
        else {
            return -EINVAL;
        }
    */
        
        /*1. get the next empty fd*/
        int fd = get_empty_fd(curproc);

/*        if(fd == -EMFILE){
            dbg(DBG_PRINT, "NEWPATH\n");
            return -EMFILE;
        }*/
	/*2. get a new file obj*/
        file_t *f_obj = fget(-1);
	/*handle error case: ENOMEM*/
/*	    if(f_obj == NULL){
            dbg(DBG_PRINT, "NEWPATH\n");
	        return -ENOMEM;
	    }*/

	/*3. point the file table entry to this obj*/
        curproc->p_files[fd] = f_obj;

        /*4. set f_mode*/
        if(oflags == O_RDONLY){
            dbg(DBG_PRINT, "(GRADING2C 1)\n");
            f_obj->f_mode = FMODE_READ;
        }
        else if(oflags & O_WRONLY){
            dbg(DBG_PRINT, "(GRADING2B)\n");
            f_obj->f_mode = FMODE_WRITE;
        }
        else if(oflags & O_RDWR){
            dbg(DBG_PRINT, "(GRADING2A)\n");
            f_obj->f_mode = FMODE_READ + FMODE_WRITE;
        }

        if(oflags & O_APPEND){
            dbg(DBG_PRINT, "(GRADING2B)\n");
            f_obj->f_mode += FMODE_APPEND;
        }

	/*5. get the vnode for the file_t*/
        vnode_t *res_vnode = NULL;

        int res;
        res = open_namev(filename, oflags, &res_vnode, NULL);

    /*handle error case: ENAMETOOLONG, ENOENT, ENOTDIR. These 3 errors are handled in dir_namev called by open_namev*/
        if(res <0) {
            curproc->p_files[fd] = NULL;
            fput(f_obj);
            dbg(DBG_PRINT, "(GRADING2B)\n");
            return res;
        }
	/*handle error case: EISDIR*/
        if((res_vnode->vn_mode & S_IFDIR) && 
            (f_obj->f_mode & FMODE_WRITE)){
            vput(res_vnode);
            dbg(DBG_PRINT, "(GRADING2B)\n");
            return -EISDIR;
        }

        /*handle error case: ENXIO*/
/*        if(((res_vnode->vn_mode & S_IFCHR) && !bytedev_lookup(res_vnode->vn_devid))
            || ((res_vnode->vn_mode & S_IFBLK) && !blockdev_lookup(res_vnode->vn_devid))) {
            dbg(DBG_PRINT, "NEWPATH\n");
            return -ENXIO;
        }*/

	/*6. fill in the field of file_t*/
        /*res_vnode->vn_ops->stat(ddstruct vnode *vnode, struct stat *buf)*/
        f_obj->f_pos = 0;
        f_obj->f_refcount = 1;
        f_obj->f_vnode = res_vnode;
        dbg(DBG_PRINT, "(GRADING2A)\n");

	/*7. return fd*/
        return fd;
}
